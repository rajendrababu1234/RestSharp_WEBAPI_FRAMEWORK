﻿using System;
using TechTalk.SpecFlow;
using RestSharp_SpecFlow_Framework.Utils;

namespace RestSharp_SpecFlow_Framework.StepDefinitions
{
    [Binding]
    public class GetEmployeeSteps
    {
        string jsonBody;

        [Given(@"Add the serialized body to the API request")]
        public void GivenAddTheSerializedBodyToTheAPIRequest()
        {
            SharedSteps.request.AddJsonBody(jsonBody);
        }
    }
}
