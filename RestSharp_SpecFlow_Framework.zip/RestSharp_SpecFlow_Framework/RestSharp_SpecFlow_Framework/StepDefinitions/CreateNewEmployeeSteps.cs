﻿using RestSharp.Serialization.Json;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using RestSharp_SpecFlow_Framework.Utils;
using RestSharp_SpecFlow_Framework.Models;

namespace RestSharp_SpecFlow_Framework.StepDefinitions
{
    [Binding]
    public class CreateNewEmployeeSteps
    {
        private static CreateEmployee new_emloyee;
        string jsonBody;

        [When(@"I create a request body with the following values")]
        public void WhenICreateARequestBodyWithTheFollowingValues(Table table)
        {
            new_emloyee = table.CreateInstance<CreateEmployee>();
            var obj = new CreateEmployee()
            {
                name = new_emloyee.name,
                salary = new_emloyee.salary,
                age = new_emloyee.age
            };
            JsonSerializer serializer = new JsonSerializer();
            jsonBody = serializer.Serialize(obj);
        }
        
        [When(@"Add the serialized body to the API request")]
        public void WhenAddTheSerializedBodyToTheAPIRequest()
        {
            SharedSteps.request.AddJsonBody(jsonBody);
        }
    }
}
